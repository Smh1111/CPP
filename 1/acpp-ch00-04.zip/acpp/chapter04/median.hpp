#ifndef ACPP_MEDIAN_HPP
#define ACPP_MEDIAN_HPP

// `median.hpp' -- final version
#include <vector>

double median(std::vector<double>);

#endif /* ACPP_MEDIAN_HPP */
